#include <stdio.h>

void imprimir(int s);

int main()
{
  int n1,n2;
  int s = 0;
  printf("Introdueix dos nombres \n");
  scanf("%d %d",&n1 ,&n2);
  s = n1+n2;
  imprimir(s);
}

void imprimir (int s)
{
  printf("La suma es:%d\n",s);
}
