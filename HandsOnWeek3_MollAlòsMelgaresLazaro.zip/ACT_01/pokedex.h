#ifndef _POKEDEX_H_
#define _POKEDEX_H_
int add_pokemon();
int remove_pokemon();
int show_pokemon();
int init_pokedex();
#endif // _POKEDEX_H_