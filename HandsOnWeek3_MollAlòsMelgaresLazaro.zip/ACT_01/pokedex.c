#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "pokedex.h"
 
int add_pokemon(){
printf("[add_pokemon]: @NOT IMPLEMENTED \n");
return EXIT_SUCCESS;
}
 
int show_pokemon(){
printf("[show_pokemon]: @NOT IMPLEMENTED \n");
return EXIT_SUCCESS;
}
 
int remove_pokemon(){
printf("[remove_pokemon]: @NOT IMPLEMENTED \n");
return EXIT_SUCCESS;
}
 
int init_pokedex(){
printf("[init_pokedex]: @NOT IMPLEMENTED \n");
return EXIT_SUCCESS;
}