

#ifndef _POKEDEX_H_
#define _POKEDEX_H_



int add_pokemon(int id, char *name, double weight, double height );
int remove_pokemon();
int show_pokemon(int pos);
int init_pokedex();
#endif 